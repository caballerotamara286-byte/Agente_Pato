# Pato Paredes | Bermejo Salvaje · Acusado en El Gran Juicio de la IA

Humano digital ficticio de El Gran Juicio de la IA (ISFD y T «República Federal de Alemania», El Colorado, Formosa). Creador de contenido y influencer de ecoturismo que declara por voz ante la fiscalía y el curso.

## Publicarlo en GitHub Pages
1. Creá un repositorio público y subí estos archivos (**Add file → Upload files → Commit changes**).
2. En **Settings → Pages**, elegí **Deploy from a branch**, rama **main**, carpeta **/ (root)**, y tocá **Save**.
3. Abrí `https://TU_USUARIO.github.io/NOMBRE_DEL_REPO/`, tocá **Hablar** y permití el micrófono.

## El agente
- ID: `agent_5301m7bhw2tgfjz9725f6j6qgaqy`. Para usar otro sin tocar el código: `index.html?agente=TU_ID`.
- Tiene que ser **público**: en ElevenLabs, pestaña *Security*, autenticación desactivada. Si usás lista de dominios, agregá `TU_USUARIO.github.io`.

## Qué hace la figura
- Mueve la boca según cada letra que dice el agente y según el sonido real.
- Se puede girar 360°; mira a quien la rodea; gesticula al hablar.
- «Escucharlo sin conectarse» usa la voz del dispositivo, sin gastar créditos.

Necesita internet: la voz viaja por ElevenLabs y la figura usa Three.js desde jsDelivr. Cada conversación consume créditos de ElevenLabs.
